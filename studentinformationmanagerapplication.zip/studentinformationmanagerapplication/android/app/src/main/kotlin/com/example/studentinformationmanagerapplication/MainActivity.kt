package com.example.studentinformationmanagerapplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
